# Salone - Free Bootstrap 5 Business Template 

- [Demo](https://themewagon.github.io/Salone/)

#### Download

- [Download from ThemeWagon](https://themewagon.com/themes/salone/)

## Getting Started

Clone Repository

```
git clone https://github.com/themewagon/Mantis-Vue.git
```

## Author

```
Salone is developed by Team HTML Codex.
```

## License

- Design and Code is Copyright &copy; [HTML Codex](https://htmlcodex.com/).
- Licensed cover under [MIT]
- Distributed by [ThemeWagon](https://themewagon.com)
